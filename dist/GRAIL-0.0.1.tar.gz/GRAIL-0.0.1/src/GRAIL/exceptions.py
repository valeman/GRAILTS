class ProtocolNotFound(Exception):
    pass

class InitializationMethodNotFound(Exception):
    pass

class KernelNotFound(Exception):
    pass

class SamplingMethodNotFound(Exception):
    pass